
CREATE DATABASE `register_table`;
USE `register_table`;

CREATE TABLE `users`(
`id` INT PRIMARY KEY AUTO_INCREMENT,
`username` VARCHAR(255),
`email` VARCHAR(255),
`password` VARCHAR(255)
);

SELECT * FROM `users`;