<?php
session_start();
require_once "../php/database.php";

if(!isset($_SESSION["email"])) {
    header("location: ../index.html");
} else {
    $email = $_SESSION["email"];

    $name_query = "SELECT * FROM users WHERE email = '$email'";
    $name_result = $sql->query($name_query);
    if($name_result->num_rows > 0) {
        while($data = $name_result->fetch_assoc()) {
            $username = $data["username"];
        }
    }

    if(isset($_SESSION["logged_in"])) {
        $status = "You are logged in";
    } else {
        $status ="Thanks for signing up";
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="../css/home.css">
</head>
<body>
    <div class="home">
        <div class="image">
            <img src="../images/img2.png" alt="">
        </div>
        <div class="status">
            <div>
            <p>Hi, <?php echo $username ?></p>
            <p><?php echo $status ?></p>
            <button onclick="window.location='../php/logOut.php'">LOG OUT</button>
        </div>
        </div>
    </div>
</body>
</html>